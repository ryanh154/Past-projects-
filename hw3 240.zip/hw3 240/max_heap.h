// Copyright [2018] <Ryan Hinson>
#pragma once
#include<iostream>
void bubbleUp(int count, int heap[]);

void bubbleDown(int count, int heap[]);

void Add(int item, int heap[], int count);

int Remove(int heap[], int count);

void MaxHeapify(int array[], int size);

void HeapSortAsc(int array[], int size);
