  // Copyright <RyanHinson>[2018]
#include "vector2d.h"  //NOLINT
  Vector2d::Vector2d() {
  x_ = 0.0;
  y_ = 0.0;
}
Vector2d::Vector2d(double x, double y) {
  x_ = x;
  y_ = y;
}
double Vector2d::x() const {
  return x_;
}
double Vector2d::y() const {
  return y_;
}
const Vector2d Vector2d::Add(const Vector2d& lhs) const {
  Vector2d ab;
  ab.x_ = x_+ lhs.x_;
  ab.y_ = y_+ lhs.y_;
  return ab;
}
const Vector2d Vector2d::Subtract(const Vector2d& lhs) const {
  Vector2d ab;
  ab.x_ = x_ -lhs.x_;
  ab.y_ = y_ -lhs.y_;
  return ab;
}
const Vector2d Vector2d::Reverse() const {
  Vector2d ab;
  ab.x_ = -x_;
  ab.y_ = -y_;
  return ab;
}
const Vector2d Vector2d::Scale(double x) const {
  Vector2d ab;
  ab.x_ = x_ * x;
  ab.y_ = y_ * x;
  return ab;
}
bool Vector2d::EqualTo(const Vector2d& lhs) const {
  if (y_ == lhs.y_ && x_ == lhs.x_) {
  return true;
} else {
  return false;
  }
}
bool Vector2d::NotEqualTo(const Vector2d& lhs) const {
  if (y_ != lhs.y_ || x_ != lhs.x_ )
  return true;
  else
  return false;
}

  double Vector2d::GetLength() const {
  double ans = sqrt(x_*x_+y_*y_);
  return ans;
}

  const Vector2d Vector2d::GetUnit() const {
  double mag = (sqrt(x_*x_+y_*y_));
  Vector2d ans(x_/mag, y_/mag);
  return ans;
}
  const string Vector2d::ToString() const {
  string a = to_string(x_);
  string b = to_string(y_);
  string c = "(" + a +", " + b + ")";
  return c;
}
