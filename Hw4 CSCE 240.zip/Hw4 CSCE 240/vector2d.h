// Copyright <Ryan Hinson> [2018]
#ifndef __VECTOR2D_H__  //NOLINT
#define __VECTOR2D_H__ //NOLINT
#include <string>
#include <cmath>
using std::string;
using std::to_string;

class Vector2d {
 public:
  Vector2d();
  Vector2d(double, double);

  double x() const;
  double y() const;

  const Vector2d Add(const Vector2d&) const;
  const Vector2d Subtract(const Vector2d&) const;

  const Vector2d Reverse() const;

  const Vector2d Scale(double) const;

  bool EqualTo(const Vector2d&) const;
  bool NotEqualTo(const Vector2d&) const;

  double GetLength() const;

  const Vector2d GetUnit() const;

  const string ToString() const;

 private:
  double x_;
  double y_;
};
#endif //NOLINT
