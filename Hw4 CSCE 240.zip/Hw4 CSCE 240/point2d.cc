// Copyright <Ryan Hinson> [2018]
#ifndef _POINT2D_CC_  //NOLINT
#define _POINT2D_CC_  //NOLINT
#include "point2d.h"  //NOLINT


  Point2d::Point2d() {
  x_ = 0;
  y_ = 0;
}
  Point2d::Point2d(double x, double y) {
  x_ = x;
  y_ = y;
}

  double Point2d::x() const {
  return x_;
}
  double Point2d::y() const {
  return y_;
}

  const Point2d Point2d::Add(const Vector2d& lhs) const {
  Point2d ab;
  ab.x_ = lhs.x() + x_;
  ab.y_ = lhs.y() + y_;
  return ab;
}
  const Vector2d Point2d::Subtract(const Point2d& lhs) const {
  Vector2d ab(x_-lhs.x_, y_-lhs.y_);
  return ab;
}

  bool Point2d::EqualTo(const Point2d& lhs) const {
  if ( x_ == lhs.x() && y_ == lhs.y())
  return true;
  else
  return false;
}
  bool Point2d::NotEqualTo(const Point2d& lhs) const {
  if ( x_ != lhs.x() || y_ != lhs.y())
  return true;
  else
  return false;
}

  double Point2d::DistanceToSquared(const Point2d& lhs) const {
  Point2d ab;
  double dis1 = ab.x() - lhs.x();
  double dis2 = ab.y() - lhs.y();
  double ans = (dis1*dis1) + (dis2*dis2);
  return ans;
}
  double Point2d::DistanceTo(const Point2d& lha) const {
  double distance = sqrt(DistanceToSquared(lha));
  return distance;
}

  const string Point2d::ToString() const {
  string a = to_string(x_);
  string b = to_string(y_);
  string c = "(" + a +", " + b + ")";
  return c;
}

  ostream& Point2d::Extract(ostream& x) const {
  x<< "(" << x_ << ", " << y_ << ")";
  return x;
}
  istream& Point2d::Insert(istream& x) {
  double a;
  double b;
  x >> a >> b;
  x_ = a;
  y_ = b;
  return x;
}
#endif  //NOLINT
