// Copyright <Ryan Hinson> [2018]
#ifndef _POINT2D_H_  //NOLINT
#define _POINT2D_H_  //NOLINT
#include <iostream>
using std::istream;
using std::ostream;
using std::cin;
#include <string>
using std::string;

#include "vector2d.h" //NOLINT

class Point2d {
 public:
  static bool Collinear(const Point2d&, const Point2d&, const Point2d&);

  Point2d();
  Point2d(double, double);

  double x() const;
  double y() const;

  const Point2d Add(const Vector2d&) const;
  const Vector2d Subtract(const Point2d&) const;

  bool EqualTo(const Point2d&) const;
  bool NotEqualTo(const Point2d&) const;

  double DistanceToSquared(const Point2d&) const;
  double DistanceTo(const Point2d&) const;

  const string ToString() const;

  ostream& Extract(ostream&) const;
  istream& Insert(istream&);

 private:
  double x_;
  double y_;
};
#endif  //NOLINT
