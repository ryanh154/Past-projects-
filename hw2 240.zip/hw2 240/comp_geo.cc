// Copyright [2018]<Ryan Hinson>
#include"comp_geo.h" //NOLINT

double GetCircumference(double xC, double yC, double xE, double yE) {
  double pi = 3.14;
  double xD = xE - xC;
  double yD = yE - yC;
  double y = yD * yD;
  double x = xD * xD;

  double distance = sqrt(x+y);
  double cir = 2*pi*distance;
  return cir;
}

double GetVolume(double xC, double yC, double xE, double yE) {
  double pi = 3.14;
  double distance = GetDistance(xC, yC, xE, yE);
  double area = pi* (distance * distance);
  return area;
}

double GetPerimeter(double xLL, double yLL, double xUR, double yUR) {
  double xD = xUR - xLL;
  double yD = yUR - yLL;
  double perimeter = (xD * 2) + (yD * 2);
  return perimeter;
}

double GetDistanceSquared(double xLL, double yLL, double xUR, double yUR) {
  double xD = xUR - xLL;
  double yD = yUR - yLL;
  double y = yD * yD;
  double x = xD * xD;
  double sqrt = y+x;
  return sqrt;
}

double GetDistance(double xLL, double yLL, double xUR, double yUR) {
  double xD = xUR - xLL;
  double yD = yUR - yLL;
  double y = yD * yD;
  double x = xD * xD;
  double distance = sqrt(y+x);
  return distance;
}

