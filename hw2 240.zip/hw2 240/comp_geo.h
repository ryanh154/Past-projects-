// Copyright [2018] <Ryan Hinson>
#pragma once
#include<iostream>
#include<cmath>
using std::cout;
using std::cin;


double GetCircumference(double, double, double, double);

double GetPerimeter(double, double, double, double);

double GetDistanceSquared(double, double, double, double);

double GetDistance(double, double, double, double);
